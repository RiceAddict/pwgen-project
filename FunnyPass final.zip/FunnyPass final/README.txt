This is a package for a simple password manager FunnyPass. All dependencies have been included in the
exe so the user does not have to install anything. Resources in the funnyresources folder can be changed
without damaging the program if the new resources are named the same as the original files.

All that the user needs to do is keep the FunnyPass.exe file one level above the funnyresources folder
and run the exe to use the program.